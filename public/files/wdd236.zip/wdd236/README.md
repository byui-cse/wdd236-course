# Web Development Course Workspace

Use this workspace to plan your learning and build web apps. An app can grow
across several learning contracts; you do not need a new app for every contract.

## Where things go

- `contracts/c1.md`, `contracts/c2.md`, and so on: your learning contracts.
- `contracts/c1/`, `contracts/c2/`, and so on: contract-specific notes and
  evidence, when needed.
- `apps/`: your web apps. The starter app is `apps/website/`.
- `apps/<app>/context/`: current specifications, wireframes, and other
  resources for that app, when needed.
- `reviews/`: review materials.

Link each contract to the relevant app and evidence. For example, a trail card
wireframe belongs with its app, while notes about what you learned while making
it belong with the contract. If you need to preserve an earlier wireframe as
evidence, keep a dated copy with the contract.

## Start a contract

1. Add your contract in `contracts/` and decide what you want to learn.
2. Choose an existing app or create a new app in `apps/` when your work calls
   for one. Ask for help if you are unsure.
3. Link your contract to the app and add planning resources and evidence as
   needed.
4. Build and verify your work, and record what you learned. You are responsible
   for understanding and checking any AI-generated work.

## Run an app

Install [Vite+](https://viteplus.dev/guide/) if you have not already. Open a
terminal in the workspace root (the folder containing this README) and install
the workspace dependencies:

```bash
vp install
```

From the same directory, start the development server for the starter app:

```bash
vp -C apps/website dev
```

Replace `website` with your app's folder name when working on another app.
Open the local address printed in the terminal. Press `Ctrl+C` to stop the
server. Alternatively, change into the app's folder with `cd apps/website`
and run `vp dev` there.

At the workspace root, `vp run dev` is different: it runs a script that
currently starts `website` regardless of which app you want. The explicit
`vp -C` command above avoids relying on the root default or app picker.

## Check your work

From the workspace root, `vp check` checks formatting, lint, and types, and
`vp run -r build` builds apps with a build script. When you add tests, run the
test command documented for your app; `vp test` can run Vitest tests from the
workspace root. The starter does not yet contain tests, so finding no tests is
not the same as passing tests. The root `vp run ready` script also expects a
test script to exist, so it will not complete until one is added.

Apps share workspace tooling and dependencies. If you later copy an app out of
this workspace, ask for help replacing its workspace references and setting up
its own dependencies.
