<!--VITE PLUS START-->

# Using Vite+, the Unified Toolchain for the Web

This project is using Vite+, a unified toolchain built on top of Vite, Rolldown, Vitest, tsdown, Oxlint, Oxfmt, and Vite Task. Vite+ wraps runtime management, package management, and frontend tooling in a single global CLI called `vp`. Vite+ is distinct from Vite, and it invokes Vite through `vp dev` and `vp build`. Run `vp help` to print a list of commands and `vp <command> --help` for information about a specific command.

Docs are local at `node_modules/vite-plus/docs` or online at https://viteplus.dev/guide/.

## Built-in Commands vs Scripts

`vp <name>` runs a built-in command. `vp run <name>` runs a `package.json` script or a `vite.config.ts` task. Scripts cannot overwrite built-ins, so `vp dev` and `vp run dev` may do different things. Check `package.json` and `vite.config.ts` first, and run `vp run <name>` when the project defines a script or task with that name.

## New Applications

When scaffolding a new application you should place it in the /apps directory.

## Tool Versions

Run `vp toolchain` to show versions and relationships in the active Vite+
release. Add a tool name to select part of the graph. For example, run
`vp toolchain vite`. Use `--global` to ignore the local `vite-plus` package. Use
`vp why <package>` to show the package-manager dependency graph.

## Review Checklist

- [ ] Run `vp install` after pulling remote changes and before getting started.
- [ ] Run `vp check` and `vp test` to format, lint, type check and test changes.
- [ ] Check if there are `vite.config.ts` tasks or `package.json` scripts necessary for validation, run via `vp run <script>`.
- [ ] If setup, runtime, or package-manager behavior looks wrong, run `vp env doctor` and include its output when asking for help.

<!--VITE PLUS END-->

# Course workflow

This is a course workspace for students who may be new to web development
tools. Explain commands and the directory they run from in plain language.

- A new `contracts/cN.md` starts a learning contract, not automatically a new
  app. Read the contract, identify the relevant work, and ask the student
  whether to continue an existing app or create one when that is unclear.
  One app can support multiple contracts, and a contract can involve more
  than one app.
- Put apps in `apps/`. Use the existing Vite+ workspace and its catalog when
  scaffolding; do not create a nested workspace or Git repository. Keep apps
  independent of each other's source unless the student explicitly wants a
  shared dependency. They need not be independently installable outside this
  workspace.
- Put current app-specific specifications, wireframes, and resources in
  `apps/<app>/context/`. Put contract-specific notes and evidence in
  `contracts/cN/`. Create these directories only when needed. Link the
  contract to its app and relevant evidence. If an evolving app artifact must
  be preserved as assessment evidence, keep a dated copy with the contract.
- Honor the student's learning plan and ownership: do not write material the
  contract assigns to the student, invent evidence, or claim learning or
  verification that did not happen. Help students understand and verify
  generated work.
- Prefer modules within an app for organizing code. Introduce a shared package
  only when there is a concrete need or learning goal, and explain the extra
  dependency and build steps.
- For student-facing development instructions, use
  `vp -C apps/<app> dev` from the workspace root to select the app explicitly.
  `vp run dev` at the root instead runs the root script, which currently
  targets `website`.
- Run relevant tests when they exist. This starter has no tests until students
  add them; a no-tests result is not a passing test run.
